from pathlib import Path
import subprocess,json,time
R=Path(__file__).resolve().parent;E=R/'exports';scenes=json.loads((R/'storyboard.json').read_text());parts=[(E/'body-prefix-22-84.mp4',62)]+[(E/'integration-fixed-preview.mp4' if s['id']=='integration' else E/'segments'/f'{s["id"]}.mp4',s['duration']) for s in scenes if s['start']>=84]
def ready(p,d):
 try:
  info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(p)],stderr=subprocess.DEVNULL));return abs(float(info['format']['duration'])-d)<.01
 except:return False
while not all(ready(p,d) for p,d in parts):time.sleep(5)
normalized=E/'normalized';normalized.mkdir(exist_ok=True);fixed=[]
for source,duration in parts:
 dest=normalized/source.name
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(source),'-map','0:v:0','-c','copy','-video_track_timescale','90000',str(dest)],check=True);fixed.append(dest)
listing=E/'segments-list.txt';listing.write_text(''.join(f"file '{p}'\n" for p in fixed));subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(listing),'-c','copy','-video_track_timescale','90000',str(E/'body-master-reviewed.mp4')],check=True);print('All official rendered scene segments assembled with matching 90kHz time bases',flush=True)
