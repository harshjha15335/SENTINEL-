from pathlib import Path
import numpy as np,soundfile as sf,json,subprocess
R=Path(__file__).resolve().parent;A=R/'audio';sr=48000;duration=172;n=duration*sr;rng=np.random.default_rng(51791);music=np.zeros(n,dtype=np.float32);fx=np.zeros(n,dtype=np.float32);scenes=json.loads((R/'storyboard.json').read_text());voice,_=sf.read(A/'narration.wav',dtype='float32')
def add(dst,start,x):
 i=round(start*sr);startskip=max(0,-i);i=max(0,i);l=min(len(x)-startskip,len(dst)-i)
 if l>0:dst[i:i+l]+=x[startskip:startskip+l]
# Original felt-key ostinato, warm low strings and restrained pulse. No stock music.
chords=[[146.8324,220,261.6256,329.6276],[174.6141,220,261.6256,349.2282],[116.5409,174.6141,233.0819,293.6648],[130.8128,195.9977,261.6256,329.6276]]
beat=60/112
for bar in range(81):
 chord=chords[(bar//4)%4];at=bar*beat*4
 for j in range(4):
  f=chord[j];t=np.arange(round(sr*3.5),dtype=np.float32)/sr;env=(1-np.exp(-t*60))*np.exp(-t*1.5);note=(np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*f*2.003*t)+.07*np.sin(2*np.pi*f*3.01*t))*env*.013;add(music,at+j*beat,note)
 t=np.arange(round(sr*beat*4.5),dtype=np.float32)/sr;env=np.sin(np.minimum(1,t/(beat*4.5))*np.pi)**2
 for f in chord[:3]:add(music,at,(np.sin(2*np.pi*f*.5*t)+.25*np.sin(2*np.pi*f*1.001*t))*env*.004)
 if at>22 and at<161:
  for j in [0,2]:
   t=np.arange(round(sr*.25),dtype=np.float32)/sr;add(music,at+j*beat,.033*np.sin(2*np.pi*(58*t-24*t*t))*np.exp(-t*20))
  for j in range(8):
   t=np.arange(round(sr*.06),dtype=np.float32)/sr;noise=rng.normal(0,.0025,len(t)).astype(np.float32);add(music,at+j*beat*.5,noise*np.exp(-t*70))
# Every major entrance has a designed pre-roll gesture and low impact, varying pitch/direction.
cues=[0,4,8,12,16]+[s['start'] for s in scenes[1:]]+[126.5,166.6]
for j,at in enumerate(cues):
 t=np.arange(round(sr*.55),dtype=np.float32)/sr;noise=rng.normal(0,1,len(t)).astype(np.float32);smooth=np.convolve(noise,np.ones(15,dtype=np.float32)/15,mode='same');env=np.sin(np.pi*t/.55)**2;whoosh=(noise*.005+smooth*.045)*env;add(fx,at-.36,whoosh)
 t=np.arange(round(sr*.75),dtype=np.float32)/sr;impact=.07*np.sin(2*np.pi*((55+j%5*4)*t-13*t*t))*np.exp(-t*9);add(fx,at,impact)
# Final restrained brand chord, synchronized with wordmark settle.
t=np.arange(sr*4,dtype=np.float32)/sr;env=(1-np.exp(-t*9))*np.exp(-t*1.2)
for f in [146.8324,220,293.6648,440]:add(fx,166.6,.018*np.sin(2*np.pi*f*t)*env)
# Smooth score ducking follows voice energy without pumping consonants.
block=480;en=np.array([np.sqrt(np.mean(voice[i:i+block]**2)) for i in range(0,n,block)]);en=np.convolve(en,np.ones(35)/35,mode='same');duck=np.interp(np.arange(n)/block,np.arange(len(en)),np.clip(1-en*6,.32,1)).astype(np.float32);t=np.arange(n,dtype=np.float32)/sr;fade=np.minimum(1,np.minimum(t/1.2,(duration-t)/2.2)).clip(0,1);music*=duck*fade;fx*=fade
left=voice+music+fx;right=voice+np.roll(music,199)*.97+fx
sf.write(A/'music-and-effects.wav',np.stack([music+fx,np.roll(music,199)*.97+fx],1),sr,subtype='PCM_24');sf.write(A/'mix-unmastered.wav',np.stack([left,right],1),sr,subtype='PCM_24')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(A/'mix-unmastered.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=10','-ar','48000','-ac','2',str(A/'final-mix.wav')],check=True)
caps=json.loads((R/'captions.json').read_text())
def stamp(ms,sep=','):
 ms=round(ms);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}{sep}{ms%1000:03}'
(R/'exports/SENTINEL_Rebuild_Subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["startMs"])} --> {stamp(c["endMs"])}\n{c["text"]}' for i,c in enumerate(caps))+'\n')
(R/'exports/SENTINEL_Rebuild_Subtitles.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{stamp(c["startMs"],".")} --> {stamp(c["endMs"],".")}\n{c["text"]}' for c in caps)+'\n')
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DM Sans,29,&H00F7F4EE,&H00F7F4EE,&H001B101B,&HAA1B101B,0,0,0,0,100,100,0,0,3,8,0,2,150,150,22,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def ass(t):
 cs=round(t/10);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
(R/'assets/captions.ass').write_text(header+'\n'.join(f'Dialogue: 0,{ass(c["startMs"])},{ass(c["endMs"])},Default,,0,0,0,,{c["text"]}' for c in caps)+'\n')
(A/'sound-cues.json').write_text(json.dumps({'transition_times_seconds':cues,'bpm':112,'score':'Original procedural felt-key and warm harmonic score','voice':'Local AI-generated Kokoro bf_emma; not previous am_michael','master_target':'-16 LUFS / -1.5 dBTP / stereo48k','paid_calls':0},indent=2));print('Original score, foley, final mix and subtitles ready')
