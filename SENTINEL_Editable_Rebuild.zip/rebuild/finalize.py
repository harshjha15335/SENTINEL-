from pathlib import Path
import subprocess,json,time,hashlib
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent.parent;O=R/'rebuild';E=O/'exports';body=E/'body-master-reviewed.mp4';patch=E/'integration-fixed-preview.mp4'
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)],stderr=subprocess.DEVNULL))
def run(a):subprocess.run(a,check=True,stdout=subprocess.DEVNULL)
while True:
 try:
  info=probe(body)
  if abs(float(info['format']['duration'])-150)<.01:break
 except Exception:pass
 time.sleep(5)
print('Body ready for final assembly',flush=True)
listing=E/'concat.txt';listing.write_text(f"file '{E/'intro-preview.mp4'}'\nfile '{body}'\n")
visual=E/'visual-master.mp4';run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(listing),'-c','copy',str(visual)])
final=E/'SENTINEL_Cinematic_Rebuild_1080p.mp4';filters=f"trim=end_frame=5124,tpad=stop_mode=clone:stop_duration=1.2,ass={O}/assets/captions.ass:fontsdir={R}/assets/fonts-final,scale=in_color_matrix=bt601:in_range=tv:out_range=pc,format=rgb24,scale=out_color_matrix=bt709:out_range=tv,format=yuv420p"
run(['ffmpeg','-y','-v','warning','-threads','2','-i',str(visual),'-i',str(O/'audio/final-mix.wav'),'-map','0:v:0','-map','1:a:0','-vf',filters,'-c:v','libx264','-preset','medium','-crf','18','-maxrate','4M','-bufsize','8M','-threads','2','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','aac','-b:a','256k','-ar','48000','-ac','2','-t','172','-movflags','+faststart',str(final)])
info=probe(final);video=next(s for s in info['streams'] if s['codec_type']=='video');audio=next(s for s in info['streams'] if s['codec_type']=='audio');assert abs(float(info['format']['duration'])-172)<.01;assert (video['width'],video['height'],video['r_frame_rate'],video['pix_fmt'])==(1920,1080,'30/1','yuv420p');assert audio['channels']==2 and audio['sample_rate']=='48000';assert final.stat().st_size<100_000_000
(O/'audit/final-ffprobe.json').write_text(json.dumps(info,indent=2));run(['ffmpeg','-v','error','-i',str(final),'-f','null','-'])
# Visual review covers the complete duration at 2-second intervals.
frames=O/'previews/final';frames.mkdir(exist_ok=True)
run(['ffmpeg','-y','-v','error','-i',str(final),'-vf','fps=1/2,scale=640:360','-q:v','2',str(frames/'frame-%03d.jpg')])
files=sorted(frames.glob('frame-*.jpg'));font=ImageFont.truetype(str(R/'assets/fonts-final/manrope.ttf'),18)
for page in range((len(files)+19)//20):
 subset=files[page*20:(page+1)*20];sheet=Image.new('RGB',(1920,1400),'#201a2b');d=ImageDraw.Draw(sheet)
 for j,p in enumerate(subset):
  im=Image.open(p);im.thumbnail((470,264));x=(j%4)*480;y=(j//4)*280;sheet.paste(im,(x,y));d.text((x+6,y+244),f'{(page*20+j)*2:03}s',font=font,fill='white')
 sheet.save(O/'previews'/f'final-contact-{page+1}.jpg',quality=92)
for t in [21.8,27.9,35.9,43.9,56.9,63.9,64.5,70,83.9,91.9,103.9,111.9,119.9,126.6,131.9,140.9,149.9,161.9,166.8,171.8]:run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(final),'-frames:v','1',str(O/'previews'/f'final-{t}.jpg')])
result={'file':str(final),'duration_seconds':172,'resolution':'1920x1080','fps':30,'codec':'H264 yuv420p BT709 / AAC stereo48k','bytes':final.stat().st_size,'sha256':hashlib.sha256(final.read_bytes()).hexdigest(),'full_decode':'PASS','sampled_full_duration':'2-second intervals, plus scene ends and Gemini/closing detail checks','visual_review':'PENDING CONTACT-SHEET REVIEW','voice':'bf_emma, distinct from rejected narrator; three auditions retained','no_atempo':True,'no_new_paid_calls':True,'original_assets_preserved':True}
(O/'audit/FINAL-QA.json').write_text(json.dumps(result,indent=2));print('FINAL_ENCODE_READY',str(final),flush=True)
