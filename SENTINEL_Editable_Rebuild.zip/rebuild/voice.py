import os
os.environ['OMP_NUM_THREADS']='2'
from pathlib import Path
import json,re,subprocess
import numpy as np,soundfile as sf
from kokoro_onnx import Kokoro
R=Path(__file__).resolve().parent.parent;O=R/'rebuild';A=O/'audio';model=Kokoro(str(R/'models/kokoro-v1.0.int8.onnx'),str(R/'models/voices-v1.0.bin'))
text='A payment takes seconds. Understanding it can take much longer. SENTINEL brings detection, explanation, and investigation together. Gemini checks the records. A person decides what happens next.'
rows=[]
for voice,lang,speed in [('bf_emma','en-gb',.99),('bm_george','en-gb',1.0),('af_heart','en-us',.96)]:
 a,sr=model.create(text,voice=voice,speed=speed,lang=lang);sf.write(A/f'audition-{voice}.wav',a,sr);rows.append({'voice':voice,'duration':len(a)/sr,'speed':speed,'words_per_minute':len(text.split())/(len(a)/sr)*60,'audition_file':f'audition-{voice}.wav'});print('audition',voice,flush=True)
(A/'auditions.json').write_text(json.dumps(rows,indent=2))
scenes=json.loads((O/'storyboard.json').read_text());rate=48000;master=np.zeros(172*rate,dtype=np.float32);captions=[];timings=[]
for s in scenes:
 # Sentence-length synthesis preserves punctuation and avoids global time compression.
 samples=[];sentence_times=[];cursor=0
 for sentence in re.split(r'(?<=[.!?])\s+',s['narration']):
  a,sr=model.create(sentence.replace('—',', '),voice='bf_emma',speed=1.01,lang='en-gb');samples.extend(a);sentence_times.append((cursor,cursor+len(a)/sr,sentence));cursor+=len(a)/sr;samples.extend(np.zeros(int(sr*.18)));cursor+=.18
 raw=A/(s['id']+'-raw.wav');sf.write(raw,np.array(samples),sr);out=A/(s['id']+'.wav');subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af','loudnorm=I=-18:TP=-2:LRA=10','-ar',str(rate),str(out)],check=True);a,sr=sf.read(out)
 duration=len(a)/sr;timings.append({'scene':s['id'],'voice_seconds':duration,'available_seconds':s['duration'],'fits':duration<s['duration']-.2});start=s['start']+.15
 if duration>s['duration']-.2: print('OVERFLOW',s['id'],duration,s['duration'],flush=True)
 begin=round(start*rate);end=min(len(master),begin+len(a));master[begin:end]+=a[:end-begin]
 for a0,a1,sentence in sentence_times:
  words=sentence.split();chunks=[' '.join(words[i:i+7]) for i in range(0,len(words),7)];total=sum(map(len,chunks));t=start+a0
  for chunk in chunks:
   span=(a1-a0)*len(chunk)/total;captions.append({'text':chunk.replace('X G boost','XGBoost').replace('Shap','SHAP').replace('Supa base','Supabase').replace('P D F','PDF').replace('R O C','ROC'),'startMs':round(t*1000),'endMs':round((t+span)*1000),'timestampMs':None,'confidence':None});t+=span
 print(s['id'],round(duration,2),flush=True)
sf.write(A/'narration.wav',master,rate,subtype='PCM_24');(O/'captions.json').write_text(json.dumps(captions,indent=2));(A/'timings.json').write_text(json.dumps(timings,indent=2))
