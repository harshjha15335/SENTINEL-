import path from 'node:path';import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';import {selectComposition,renderMedia} from '@remotion/renderer';import fs from 'node:fs/promises';
const R=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const scenes=JSON.parse(await fs.readFile(R+'/rebuild/storyboard.json'));const serveUrl=await bundle({entryPoint:R+'/src/rebuild-entry.tsx',publicDir:R+'/public'});const opts={serveUrl,browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE || undefined,chromiumOptions:{gl:'swangle'},timeoutInMilliseconds:120000};const composition=await selectComposition({...opts,id:'SentinelCinematicRebuild'});await fs.mkdir(R+'/rebuild/exports/segments',{recursive:true});
for(const scene of scenes.filter(s=>s.start>=84&&s.id!=='integration')){
 const dest=R+'/rebuild/exports/segments/'+scene.id+'.mp4';try{await fs.access(dest);console.log('Existing',scene.id);continue}catch{}
 let last=-1;console.log('START',scene.id,new Date().toISOString());await renderMedia({...opts,composition,codec:'h264',crf:18,x264Preset:'fast',outputLocation:dest,concurrency:2,offthreadVideoCacheSizeInBytes:128*1024*1024,mediaCacheSizeInBytes:64*1024*1024,offthreadVideoThreads:1,frameRange:[scene.start*30,(scene.start+scene.duration)*30-1],imageFormat:'jpeg',jpegQuality:95,onProgress:({renderedFrames})=>{const bucket=Math.floor(renderedFrames/150);if(bucket!==last){console.log(scene.id,renderedFrames);last=bucket}}});console.log('DONE',scene.id,new Date().toISOString());
}
console.log('ALL_SEGMENTS_READY');
