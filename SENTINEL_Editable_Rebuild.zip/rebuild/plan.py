import json
from pathlib import Path
R=Path(__file__).resolve().parent
scenes=[
('intro',22,'A payment. A pattern. A decision.','A payment takes seconds. Understanding it can take much longer. A sudden burst of activity. An unusual amount. Records scattered across different systems. SENTINEL brings those signals together, so an analyst can see what happened—and decide what comes next.'),
('landing',6,'Follow the money.','Follow the money, from the payment to the evidence behind it.'),
('dashboard',8,'Start with what needs attention.','The Command Center brings flagged payments into focus, with the context an analyst needs to begin.'),
('transactions',8,'One payment. Full context.','Open a transaction. See its payment history, risk assessment, and the case it belongs to.'),
('risk',13,'A score you can question.','Here, the X G boost model assigns a forty-six point five percent risk score. The case is synthetic. The model runs in shadow mode, supporting review rather than moving money.'),
('shap',7,'Understand the signals.','Shap contributions explain which signals pushed this result up or down.'),
('gemini',20,'Gemini, inside the investigation.','In this separate hosted run, Gemini completes a real investigation. Seven tools read the available records and return grounded findings. Citations make the reasoning reviewable. The recommendation: request more evidence. A person still decides what happens next.'),
('tools',8,'Every finding has a source.','Open the tool trace. See which records the agent read, and follow a finding back to its source.'),
('evidence',12,'Build the evidence.','Bring documents into the case, keep their provenance, and generate a reviewable P D F packet. The evidence stays connected to the investigation.'),
('approval',8,'Human judgment stays in control.','Decision requests and independent approvals keep the next step accountable. No financial action is executed here.'),
('dispute',8,'Prepare. Review. Then decide.','Dispute Copilot prepares a grounded response. Review the evidence. External submission stays disabled.'),
('policy',12,'Explore the trade-off.','In Policy Lab, adjust a threshold and inspect the trade-off. Review the R O C and precision recall analysis against held-out synthetic data, before considering a policy change.'),
('monitor',9,'Watch for change.','Risk Monitoring compares activity and score distributions over time. A shift is a reason to investigate, not a verdict.'),
('network',9,'Connect the records.','Relationship Explorer connects payers and payments. Select a relationship, inspect the recorded history, and bring the context back to the case.'),
('integration',12,'Built on verified connections.','Earlier audits verified a genuine PayPal sandbox capture and processed Supa base events. These recorded results are separate from this synthetic walkthrough.'),
('closing',10,'Follow the money. Decide with evidence.','SENTINEL. Detection, explanation, and investigation. One connected view. Human judgment at the center.')]
at=0;out=[]
for id,duration,title,narration in scenes:
 out.append(dict(id=id,start=at,duration=duration,title=title,narration=narration));at+=duration
assert at==172
(R/'storyboard.json').write_text(json.dumps(out,indent=2))
(R/'docs/NARRATION-RECORDING-SCRIPT.md').write_text('# SENTINEL narration\n\nDelivery: composed documentary tone; conversational, precise. Allow the images to breathe. Names: SENTINEL (SEN-ti-nel), XGBoost (ex gee boost), SHAP (shap), Gemini (JEM-in-eye), Supabase (SOO-puh-base).\n\n'+'\n\n'.join(f"## {s['start']:03}–{s['start']+s['duration']:03} seconds — {s['id']}\n\n{s['narration']}" for s in out))
