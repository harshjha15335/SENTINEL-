import path from 'node:path';import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';import {selectComposition,renderStill,renderMedia} from '@remotion/renderer';import fs from 'node:fs/promises';
const R=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const mode=process.argv[2]||'previews';const browserExecutable=process.env.REMOTION_BROWSER_EXECUTABLE || undefined;
const serveUrl=await bundle({entryPoint:R+'/src/rebuild-entry.tsx',publicDir:R+'/public',onProgress:p=>{}});const opts={serveUrl,browserExecutable,chromiumOptions:{gl:'swangle',disableWebSecurity:false},timeoutInMilliseconds:120000};const composition=await selectComposition({...opts,id:'SentinelCinematicRebuild'});console.log('Composition loaded',composition.durationInFrames);
if(mode==='previews'){
 for(const time of [2,6,10,14,18,21,25,32,40,50,60,66,72,80,88,97,108,116,126,136,145,154,159,166,170]){await renderStill({...opts,composition,frame:Math.round(time*30),output:R+`/rebuild/previews/frame-${String(time).padStart(3,'0')}.jpg`,imageFormat:'jpeg',jpegQuality:92});console.log('preview',time)}
}else{
 const range=mode==='integration-fixed'?[4500,4859]:mode==='body'?[660,5159]:mode==='intro'?[0,659]:mode==='proof'?[1920,2759]:mode==='closing'?[4860,5159]:undefined;
 await renderMedia({...opts,composition,codec:'h264',crf:18,x264Preset:'fast',outputLocation:R+'/rebuild/exports/'+(mode==='body'?'body-master-reviewed.mp4':range?mode+'-preview.mp4':'visual-master.mp4'),concurrency:2,offthreadVideoCacheSizeInBytes:128*1024*1024,mediaCacheSizeInBytes:64*1024*1024,offthreadVideoThreads:1,frameRange:range,imageFormat:'jpeg',jpegQuality:95,onProgress:({renderedFrames,encodedFrames})=>{if(renderedFrames%150===0)console.log('frames',renderedFrames,'encoded',encodedFrames)}})
}
