import {registerRoot,Composition} from 'remotion';import {Rebuild} from './Rebuild';
registerRoot(()=> <Composition id="SentinelCinematicRebuild" component={Rebuild} width={1920} height={1080} fps={30} durationInFrames={5160}/>);
